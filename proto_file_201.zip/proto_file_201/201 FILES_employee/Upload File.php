<!DOCTYPE html>
<?php

session_start();


?>

<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link 
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Roboto:400,700"
    />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="../css/fontawesome.min.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/design_filter.css">
    <link rel="stylesheet" href="../css/templatemo-style-HR.css">
    <link rel="stylesheet" href="../css/reporttablestyle.css">
    <link rel="stylesheet" href="../jquery-ui-datepicker/jquery-ui.min.css" type="text/css"/>

    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
    $(function () {
        $("#category").change(function () {
            if ($(this).val() == "Others") {
                $("#txtOther").removeAttr("disabled");
                $("#txtOther").focus();
            } else {
                $("#txtOther").attr("disabled", "disabled");
            }
        });
    });
</script>



  </head>

  <body id="reportsPage">
    <div class="" id="home">
    <nav class="navbar navbar-expand-xl">
            <div class="container h-100">
                <a class="navbar-brand" href="index.php">
                    <img class="two" src="APC logo.png" width="50" height="50   ">
                </a>
                <button class="navbar-toggler ml-auto mr-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars tm-nav-icon"></i>
                </button>
            
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto h-100">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">
                                <img class="two" src="home.png" width="30" height="30">
                                <!-- Home -->
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <!-- Files -->  
                            <a class="nav-link" href="FileViewer.php"><img class="two" src="blank-page.png" width="30" height="30"></a>
                        </li>
                        <!-- Upload -->
                        <li class="nav-item">
                            <div class="topnav-centered"></div>
                            <a href="Upload File.php" class="bn11"><img class="two" src="upload.png" width="30" height="30"></a>
                            </a>
                        </li>
                        <!-- FAQ -->
                        <li class="nav-item">
                            <a class="nav-link" href="https://www.apc.edu.ph/"><img class="two" src="faq.png" width="30" height="30"></a>
                        </li>
                        <!-- Profile -->
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php"><img class="two" src="user.png" width="30" height="30"></a>
                        </li>
                    </ul>

                    <!--- User Icon --->
                    <div class="dropdown">
                        <button class="bn12" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php

                        
                                    echo $_SESSION['firstName'];
                                    echo "&nbsp;";
                                    echo $_SESSION['lastName'];
                                    ?>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                          <a class="dropdown-item" href="logout.php">Log Out</a>
                        </div>
                    </div>
            </div>
      </div>
</div>
 </nav>
 <br>
 <br>


        <div class="col-xl-9 col-lg-10 col-md-12 col-sm-12 mx-auto">
          <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
            <div class="row">
              <div class="col-10">
                <h2 class="tm-block-title d-inline-block">Upload File</h2>
              </div>
            </div>
            <div class="row tm-edit-product-row">
              <div class="col-xl-6 col-lg-6 col-md-12">
                  <div class="form-group mb-3">
                  <form action="Upload.php" method= "post" enctype="multipart/form-data">
                    <label
                      >Name
                    </label>
                    <input
                      id="foldername"
                      name="foldername"
                      type="text"
                      class="form-control validate"
                      required
                    />
                  </div>
                  <div class="form-group mb-3">
                    <label
                      for="description"
                      >Description</label
                    >
                    <textarea
                      class="form-control validate"
                      rows="3"
                      name="description"
                      required
                    ></textarea>
                  </div>
                  <div class="form-group mb-3">
                    <label
                      for="category"
                      >File Category</label
                    >
                    <select
                      class="custom-select tm-select-accounts"
                      id="category"
                      name="category"
                    >
                      <option selected>Select category</option>
                      <option value="Birth certificate">Birth certificate</option>
                      <option value="Certificates">Certificate</option>
                      <option value="Insurances">Insurances</option>
                      <option value="NBI Clearance">NBI Clearance</option>
                      <option value="Personal Data Sheet">Personal Data Sheet</option>
                      <option value="Position Description Form">Position Description Form</option>
                      <option value="Professional Teachers Licenses">Professional Teachers Licenses</option>
                      <option value="School Diplomas">School Diplomas</option>
                      <option value="Statement of Assets">Statement of Assets</option>
                      <option value="Transcript of Records">Transcript of Records</option>
                      <option value="Others">Others</option>
                    </select>

                    other:
                    <input type="text" id="txtOther" disabled="disabled" />
                  </div>
              </div>
              <div class="col-xl-6 col-lg-6 col-md-12 mx-auto mb-4">
              <div class="files">
              <div id="text"></div>
              </div>
                <div class="custom-file mt-3 mb-3">
                  <input
                    type="button"
                    name="upload"
                    class="btn btn-primary btn-block mx-auto"
                    value="UPLOAD FILE"
                    onclick="document.getElementById('upload').click();"
                    id="file"
                  />
                </div>
                <input type="file" id="upload" name="upload[]" style="display:none" accept="application/pdf" multiple> 
              </div>
              <div class="col-12">
                  <button type="submit" href="#demo-modal" class="btn btn-primary btn-block text-uppercase">Submit</button>
              </div>
              </div>
              </div>
              </div>
            </form>
            </div>
          </div>
    <footer class="tm-footer row tm-mt-small">
        <div class="col-12 font-weight-light">
        </div>
    </footer> 

    <div id="demo-modal" class="modal">
      <div class="modal__content">
         <center><h1>SUCCESS</h1></center> 
          <p>
              <h4>Your file is already submitted.</h4>
              you can now exit this message.
              <br>
              <br>
              <br><b>Thank You!</b>
          </p>         
         
          <a href="#" class="modal__close">&times;</a>
  </div>

    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../js/jquery-ui-datepicker/jquery-ui.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>

    <script type="text/javascript">
  $('#upload').bind('change', function() {
    var files = this.files;
    var i = 0;
    for(; i < files.length; i++) {
      var filename = files[i].name + "<br />";
      $("#text").append(filename);
    }
  });
</script>
  </body>
</html>