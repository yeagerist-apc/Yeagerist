<?php
$db =  new PDO("mysql:host=localhost;dbname=registrations", "root", "",);
$url = "http://localhost:8080/proto_file_201";