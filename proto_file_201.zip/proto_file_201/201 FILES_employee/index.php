<?php
    require_once 'config.php';
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="css/fontawesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/templatemo-style-employee.css">
    <link rel="stylesheet" href="css/searchbar.css">
   


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
$("#Input").on("keyup", function() {
var value = $(this).val().toLowerCase();
$("#list tr").filter(function() {
$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
});
});
});
      </script>

</head>

<div class="d-flex flex-column justify-content-center align-items-center">
</div>

<body id="reportsPage">
    <div class="" id="home">
        <nav class="navbar navbar-expand-xl">
            <div class="container h-100">
                <a class="navbar-brand" href="index.php">
                    <img class="two" src="APC logo.png" width="50" height="50   ">
                </a>
                <button class="navbar-toggler ml-auto mr-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars tm-nav-icon"></i>
                </button>
            
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto h-100">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">
                                <img class="two" src="home.png" width="30" height="30">
                                <!-- Home -->
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <!-- Files -->  
                            <a class="nav-link" href="FileViewer.php"><img class="two" src="blank-page.png" width="30" height="30"></a>
                        </li>
                        <!-- Upload -->
                        <li class="nav-item">
                            <div class="topnav-centered"></div>
                            <a href="Upload File.php" class="bn11"><img class="two" src="upload.png" width="30" height="30"></a>
                            </a>
                        </li>
                        <!-- FAQ -->
                        <li class="nav-item">
                            <a class="nav-link" href="https://www.apc.edu.ph/"><img class="two" src="faq.png" width="30" height="30"></a>
                        </li>
               
                      <!-- Profile -->
                      <li class="nav-item">
                            <a class="nav-link" href="profile.php"><img class="two" src="user.png" width="30" height="30"></a>
                        </li>
                    </ul>

                    <!--- User Icon --->
               
                    <div class="dropdown">
                    <div class="topnav-right">
                        <button class="bn12" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"  >
                       <?php

                        
                                    echo $_SESSION['firstName'];
                                    echo "&nbsp;";
                                    echo $_SESSION['lastName'];
                                    ?>
                               
                        </button>
                        
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                          <a class="dropdown-item" href="logout.php">Log Out</a>
                        </div>
                    </div>
</div>
         </div>
    </div>           
</div>

        </nav>
        <div class="container">
            <div class="row">
                <div class="col">
                    <p class="text-white mt-5 mb-5">Welcome back, <b></b>
                    <?php

echo $_SESSION['id'];
?></p>
                </div>
            </div>
            <!-- row -->
            <div class="row tm-content-row">
                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 tm-block-col">
                    <div class="tm-bg-primary-dark tm-block tm-block-taller">
                        <h2 class="tm-block-title">Profile Card</h2>
                        <div class="card">
                        <?php
                        require_once "dbConn.php";
                        $sql = "SELECT * FROM profile_photos WHERE employee_id = '".$_SESSION['id'] ."'";
                        $result = $conn->query($sql);
                        $path = "";
                        while($row = $result->fetch_assoc()) {
                            $path = $row["path"];
                        }
                        if ($path) {
                            echo '
                                <div style="width: 200px; height: 200px; overflow: hidden; margin: auto auto;" class="rounded-circle mt-5" >
                                    <img id="" src="'. $path .'" style="width: 100%;">
                                </div>
                            ';
                        } else {
                            echo '
                            <center><img src="user icon.png" alt="John" style="width:50%"></center>
                            ';
                        }
                    ?>

                            <h1></h1>
                            <p class="title"><?php
                                    echo $_SESSION['firstName'];
                                    echo "&nbsp;";
                                    echo $_SESSION['lastName'];
                                  
                                  
                                    ?>
                              <p class="title">      <?php
                                    echo $_SESSION['office'];
                                    ?></p>

                            <p>Asia Pacific College</p>



                          </div>             
                    </div>
                </div>
                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 tm-block-col">
                    <div class="tm-bg-primary-dark tm-block tm-block-taller tm-bloc -overflow"> 
                        <h2 class="tm-block-title">Checklist Viewer</h2>    
                        <table class="table1">
                            <thead>
                                <tr>
                                 
                                    <th scope="col">Employee No.</th>

                                    <th scope="col">File category</th>
                                    <th scope="col">Date Submitted</th>
                          
                                   </tr>
</thead>
                                <tbody>
                     
                                <?php

$stmt = $db->prepare("select * from employee_checklist where employee_id = '" . $_SESSION['id'] . "'");
$stmt->execute();
while($row = $stmt->fetch()){
    echo '
        <tr>

            <td>'. $row['employee_id'] .'</td>
            <td>'. $row['document_name'] .'</td>
            <td>'. $row['created_at'] .'</td>-
        
        </tr>
    ';
}

?>             
</tbody>
</table>
</td>
</tr>

</tbody>
</table>



                    </div>
                </div>
                <div class="col-12 tm-block-col">
                    <div class="tm-bg-primary-dark tm-block tm-block-taller tm-block-scroll">
                        <h2 class="tm-block-title">File Status</h2>
                        <div class="search"><input type="text" id="Input" placeholder="Type to search"></div>
                        <br>
                        <br>
                        <table class="table" id="list">
                            <thead>
                                <tr>
                                 
                                    <th scope="col">File Path</th>
                                    <th scope="col">File Category</th>
                                    <th scope="col">File Name</th>
                                    <th scope="col">Status</th>
                                    <th></th>
                                </tr>
</thead>
                                <tbody>
                         <?php

                            $stmt = $db->prepare("select * from file_uploads where employee_id = '" . $_SESSION['id'] . "'");
                            $stmt->execute();
                            while($row = $stmt->fetch()){
                                ?>
                    <tr>
                    

      
                    
                    <td><?php echo strlen($row['file_path']) > 50 ? substr($row['file_path'], 0, 50) . "..." : $row['file_path'] ?></td>
                    <td><?php echo $row['file_category']?></td>
                    <td><?php echo strlen($row['file_name']) > 40 ? substr($row['file_name'], 0, 40) . "..." : $row['file_name'] ?></td>
                    <td><?php echo $row['status']?></td>
                    <td class="text=center">
                        <?php
                            if (
                                str_contains($row['file_name'], '.pdf') ||
                                str_contains($row['file_name'], '.png') ||
                                str_contains($row['file_name'], '.jpg') ||
                                str_contains($row['file_name'], '.jpeg') ||
                                str_contains($row['file_name'], '.bmp')
                            ) {
                                echo '<a href="' . $url . '/' . $row['file_path'] .'" class="bn12" target="_blank">View</a>';
                            } else {
                                echo '<a href="' . $url . '/' . $row['file_path'] .'" class="bn12" download>View</a>';
                            }
                        ?>
                        
                    </td>
                </tr>
                <?php
                    }
                ?>
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/moment.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/tooplate-scripts.js"></script>
</body>

</html>