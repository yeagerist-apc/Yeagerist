<!DOCTYPE html>

<?php

session_start();


?>

<html lang="en">
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link 
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Roboto:400,700"
    />
    <link rel="stylesheet" href="css/fontawesome.min.css" />
    <link rel="stylesheet" href="jquery-ui-datepicker/jquery-ui.min.css" type="text/css" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/templatemo-style-employee.css">
  </head>

  <body id="reportsPage">
    <div class="" id="home">
    <nav class="navbar navbar-expand-xl">
            <div class="container h-100">
                <a class="navbar-brand" href="index.php">
                    <img class="two" src="APC logo.png" width="50" height="50   ">
                </a>
                <button class="navbar-toggler ml-auto mr-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars tm-nav-icon"></i>
                </button>
            
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto h-100">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">
                                <img class="two" src="home.png" width="30" height="30">
                                <!-- Home -->
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <!-- Files -->  
                            <a class="nav-link" href="FileViewer.php"><img class="two" src="blank-page.png" width="30" height="30"></a>
                        </li>
                        <!-- Upload -->
                        <li class="nav-item">
                            <div class="topnav-centered"></div>
                            <a href="Upload File.php" class="bn11"><img class="two" src="upload.png" width="30" height="30"></a>
                        </li>
                        <!-- FAQ -->
                        <li class="nav-item">
                            <a class="nav-link" href="https://www.apc.edu.ph/"><img class="two" src="faq.png" width="30" height="30"></a>
                        </li>
               
                      <!-- Profile -->
                      <li class="nav-item">
                            <a class="nav-link" href="profile.php"><img class="two" src="user.png" width="30" height="30"></a>
                        </li>
                    </ul>

                    <!--- User Icon --->
                    <div class="dropdown">
                        <button class="bn12" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php

                        
                                    echo $_SESSION['firstName'];
                                    echo "&nbsp;";
                                    echo $_SESSION['lastName'];
                                 
                                    ?>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                          <a class="dropdown-item" href="logout.php">Log Out</a>
                        </div>
                    </div>
          </div>
      </div>
</div>

        </nav>
 <div class="container tm-mt-big tm-mb-big">
      <div class="row">
        <div class="col-xl-15 col-lg-20 col-md-12 col-sm-12 mx-auto">
          <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
            <div class="row">
              <div class="col-12">
                <h2 class="tm-block-title d-inline-block">Profile</h2>
                
                <?php
                        require_once "dbConn.php";
                        $sql = "SELECT * FROM profile_photos WHERE employee_id = '".$_SESSION['id'] ."'";
                        $result = $conn->query($sql);
                        $path = "";
                        while($row = $result->fetch_assoc()) {
                            $path = $row["path"];
                        }
                        if ($path) {
                            echo '
                                <div style="width: 200px; height: 200px; overflow: hidden; margin: auto auto;" class="rounded-circle mt-5" >
                                    <img id="" src="'. $path .'" style="width: 100%;">
                                </div>
                            ';
                        } else {
                            echo '
                            <div class="d-flex flex-column align-items-center text-center p-3 py-5"><img class="rounded-circle mt-5" width="200px" src="../images/user icon.png"><br><span class="font-weight-bold">
                            ';
                        }
                    ?>
                    <br>
                    
              
<center>
                <?php


echo $_SESSION['firstName'];
echo "&nbsp;";
echo $_SESSION['lastName'];
?>
<br>
                </span><span class="text-black-50">

<?php
echo $_SESSION['email'];
?>
</center>
                </span></div>
    
              <label></label>
            

            </div>
            <div class="container rounded bg-white mt-5 mb-5">
              <div class="row">
                <div class="col-md-2 border-right"></div>
                  <div class="col-md-5 border-right">
                      <div class="p-3 py-5">
             
                          <div class="row mt-3">
                              <div class="col-md-12"><label class="labels">Mobile Number</label><p>
                              <?php
                                echo $_SESSION['contact'];
                                ?>
                            </p></div>
                              <div class="col-md-12"><label class="labels">Address Line 1</label><p> 
                                  
                              <?php
                                echo $_SESSION['address'];
                                ?>
                            
                            </p></div>

                              <div class="col-md-12"><label class="labels">Gender</label
                              > <p><?php
                              echo $_SESSION['gender'];
                              ?><p></div>

                            <div class="col-md-12"><label class="labels">Religion</label
                                  > <p><?php
                                  echo $_SESSION['religion'];
                                  ?><p></div>

                              <div class="col-md-12"><label class="labels">Educational Attainment</label
                              > <p><?php
                              echo $_SESSION['educational_attainment'];
                              ?><p></div>
                                     </div>
                      </div>
                  </div>
                  <div class="col-md-4">  
                      <div class="p-3 py-5">
                          <div class="col-md-12"><label class="labels">Civil Status</label><p>

                          <?php
                                echo $_SESSION['civil_status'];
                                ?>
                          </p></div> <br>
                          <div class="col-md-12"><label class="labels">Citizenship</label><p>

                            <?php
                                  echo $_SESSION['citizenship'];
                                  ?>
                            </p></div> <br>
                          <div class="col-md-12"><label class="labels">Birthday</label><p>

                          <?php
                                echo $_SESSION['birthday'];
                                ?>

                          </p></div>

                          <div class="col-md-12"><label class="labels">Office</label><p>

                          <?php
                                echo $_SESSION['office'];
                                ?>

                          </p></div>
                          <div class="col-md-12"><label class="labels">Position</label><p>

                          <?php
                                echo $_SESSION['position'];
                                ?>

                          </p></div>
                      </div>
                  </div>
              </div>
          </div>
          </div>
          </div>


    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="jquery-ui-datepicker/jquery-ui.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>