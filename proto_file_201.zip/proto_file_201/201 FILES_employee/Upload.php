<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require '../PHPMailer/src/Exception.php';
    require '../PHPMailer/src/PHPMailer.php';
    require '../PHPMailer/src//SMTP.php';

    require_once "dbConn.php";
    session_start();
    function get_size($size){
        $kb_size = $size / 1024;
        $format_size = number_format($kb_size, 2);
        return $format_size;
    }
    $allow=array('pdf');

    $uploadedFiles = $_FILES['upload'];

    // echo "<pre>";
    // var_dump($uploadedFiles);
    // exit;

    $emailSent = false;

    $no_of_files = 0;

    foreach ($uploadedFiles as $uploadedFile) {
        $no_of_files = count($uploadedFile);
        break;
    }

    for ($ctr = 0; $ctr < $no_of_files; $ctr++) {

        $size = get_size($_FILES['upload']['size'][$ctr]);

        $description = $_POST['description'];
        $category = $_POST['category'];
        $employee_id = $_SESSION['id'];

        $path = "../uploads/" . $_POST['foldername'] . "/" . $category;

        if($size < 5000){ 

            if(!file_exists($path)){

                mkdir($path, 0777, true); 
            }

            $temp_file = $_FILES['upload']['tmp_name'][$ctr];

            

            if($temp_file!=""){

                $newfilepath = $path. "/".$_FILES['upload']['name'][$ctr];

                if(move_uploaded_file($temp_file, $newfilepath)) {

                    //save to db
                    if (
                        $category == "Certificates" ||
                        $category == "Transcript of Records" 

                        //.. add here for other category
                    ) {
                        $sql = "
                            INSERT INTO file_uploads (
                                employee_id, file_category, file_path, file_name, description, status
                            ) values(
                                '${employee_id}', 
                                '${category}', 
                                '${homePath}/${newfilepath}',
                                '" . $_FILES['upload']['name'][$ctr] . "', 
                                '${description}',
                                'Approved'
                            )
                        ";
                    } else {
                        $sql = "
                            INSERT INTO file_uploads (
                                employee_id, file_category, file_path, file_name, description
                            ) values(
                                '${employee_id}', 
                                '${category}', 
                                '${homePath}/${newfilepath}', 
                                '" . $_FILES['upload']['name'][$ctr] . "', 
                                '${description}'
                            )
                        ";
                    }
                    

                    if ($conn->query($sql)) {

                        // Send email
                        $mail = new PHPMailer(true);

                        try {
                            //Server settings
                            // $mail->SMTPDebug = 1;
                            $mail->isSMTP();
                            $mail->Host = 'smtp.gmail.com';
                            $mail->SMTPAuth = true;
                            $mail->Username = 'yeagerist.apc@gmail.com';
                            $mail->Password = 'yeagerist2020';
                            $mail->SMTPSecure = 'tls';
                            $mail->Port = 587;

                            //Recipients
                            $mail->setFrom('yeagerist.apc@gmail.com', 'APC - Filescript');
                            $mail->addAddress('yeagerist.apc@gmail.com'); // HR email

                            // Content
                            $mail->isHTML(true);
                            $mail->Subject = $_POST['foldername'] . " uploaded " . $category;
                            
                            $message = "
                                Hi HR,
                                <br><br>
                                " . $_POST['foldername'] . " uploaded " . $category . " successfully. Please see URL below:
                                <br>
                                <a href='http://localhost:8080/proto_file_201/" .  str_replace("..", "", $newfilepath) . "' target='_blank'>
                                    http://localhost:8080/proto_file_201/" .  str_replace("..", "", $newfilepath) . "
                                </a>
                                
                                <br><br>
                                Cheers,
                                <br>
                                Yeagerist
                            ";

                            $mail->Body = $message;
                            $mail->send();
                            $mail->clearAddresses();
                            $mail->smtpClose();
                        } catch (Exception $e) {
                            $emailSent = false;
                            break;
                        }
                        $emailSent = true;
                    } else {
                        $emailSent = false;
                    }
                }
            } else {
                echo "Error";

            }
        }
    }

    $conn->close();

    if ($emailSent) {
        header("Location: Upload File.php?upload=success&email=sent");
    } else {
        header("Location: Upload File.php?upload=success&email=failed");
    }
?>