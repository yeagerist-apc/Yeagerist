<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


function send_email($recipient, $subject, $message){

$mail = new PHPMailer();
$mail = IsSMTP();

$mail->SMPTDebug = 0;
$mail->SMTPAuth = TRUE;
$mail->SMTPSecure = "tls";
$mail->Port = 2525;
$mail->Host = "smtp.apc.edu.ph";
$mail->Username = "notificationemail";
$mail->Password = "PtKaS08yFaodH7VU";

$mail->IsHTML(TRUE);
$mail->AddAddress($recipient,"recipient-name");
$mail->SetFrom("notificationmail","set-from-name");


$mail->Subject = $subject;
$content = $message;

$mail->MsgHTML($content);
if(!$mail->Send()){

    echo"Error while sending email.";
    var_dump($mail);
    return false;
    }else{

        echo "Email send successfully";
        return true;
    }
}
    
?>  