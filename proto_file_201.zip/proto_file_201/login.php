<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="css/fontawesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/design_filter.css">
    <link rel="stylesheet" href="css/templatemo-style.css">
    <link rel="stylesheet" href="css/login.css">



    <title>Asia Pacific College File Script Login Form</title>
    <link rel="stylesheet" href="deisgn_filter.css">
  </head>
  <body>
    <div class="wrapper">
       <div class="imgcontainer">
    </div>
      <div class="title"><img src="images/APC logo.png" alt="Avatar" class="avatar"><br>Asia Pacific File Script </div>
      <form action="validate.php" method="POST">
        <div class="field">
          <input type="email"
          id="email"
          name="email" 
          required>
          <label>Email Address</label>
        </div>
        <div class="field">
          <input type="password" 
          id="password"
          name="password"required>
          <label>Password</label>
        </div>
        <div class="content">
          <div class="checkbox">
            
        <div class="field">
          <input type="submit" value="Login">
          <?php if (isset($_GET['error'])){ ?>
		<p class="error"><?php echo $_GET['error']; ?></p>
	  <?php } ?>
        </div>
</form>

  </body>
</html>
