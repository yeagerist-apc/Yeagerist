<?php
		session_start();
		$email = $_POST['email'];
		$password = $_POST['password'];
		$firstName = $_POST['firstName'];
		$lastName = $_POST['lastName'];
		$gender = $_POST['Gender'];
		
		$conn = new mysqli('localhost','root','','registrations');
			
				if($conn->connect_error){
					die('Connection Failed : '.$conn->connect_error);
				}else{
					$stmt = $conn->prepare("select * from employees where email = ?");
					$stmt->bind_param("s", $email);
					$stmt->execute();
					$stmt_result = $stmt->get_result();
					if($stmt_result->num_rows > 0) {
						$data = $stmt_result->fetch_assoc();
						if($data['password'] === $password) {
							$_SESSION['firstName'] = $data['firstName'];
							$_SESSION['lastName'] = $data['lastName'];
							$_SESSION['id'] = $data['EmployeeID'];
							$_SESSION['middleName'] = $data['middleName'];
							$_SESSION['suffixName'] = $data['suffixName'];
							$_SESSION['religion'] = $data['religion'];
							$_SESSION['citizenship'] = $data['citizenship'];
							$_SESSION['office'] = $data['office'];
							$_SESSION['department'] = $data['department'];
							$_SESSION['position'] = $data['position'];
							$_SESSION['educational_attainment'] = $data['educational_attainment'];
							$_SESSION['gender'] = $data['gender'];
							$_SESSION['email'] = $data['email'];
							$_SESSION['address'] = $data['address'];
							$_SESSION['civil_status'] = $data['civil_status'];
							$_SESSION['contact'] = $data['contact'];
							$_SESSION['birthday'] = $data['birthday'];
							$_SESSION['profile_image'] = $data['email'];
							$_SESSION['user_type'] = $data['user_type'];
							$_SESSION['status'] = $data['status'];
							if($data['user_type']==='Admin'){
								header("Location: html/home.php");
							}else if($data['user_type']==='User'){
								header("Location: 201 FILES_employee/index.php");
							}
						} else {
							header("Location: login.php?error=Invalid email or password!");
						}
						exit();
					} else {
						header("Location: login.php?error=Invalid email or password!");
					}
				}
?>