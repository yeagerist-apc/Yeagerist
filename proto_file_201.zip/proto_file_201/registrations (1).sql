-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2022 at 11:48 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registrations`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `EmployeeID` varchar(99) NOT NULL,
  `firstName` varchar(99) NOT NULL,
  `middleName` varchar(255) NOT NULL,
  `lastName` varchar(99) NOT NULL,
  `suffixName` varchar(255) NOT NULL,
  `gender` varchar(99) NOT NULL,
  `age` int(225) NOT NULL,
  `civil_status` varchar(225) NOT NULL,
  `religion` varchar(99) NOT NULL,
  `citizenship` varchar(99) NOT NULL,
  `contact` int(11) NOT NULL,
  `email` varchar(99) NOT NULL,
  `password` varchar(99) NOT NULL,
  `office` varchar(99) NOT NULL,
  `department` varchar(225) NOT NULL,
  `position` varchar(225) NOT NULL,
  `user_type` varchar(99) NOT NULL,
  `address` varchar(225) NOT NULL,
  `birthday` date DEFAULT NULL,
  `educational_attainment` varchar(225) NOT NULL,
  `status` varchar(99) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`EmployeeID`, `firstName`, `middleName`, `lastName`, `suffixName`, `gender`, `age`, `civil_status`, `religion`, `citizenship`, `contact`, `email`, `password`, `office`, `department`, `position`, `user_type`, `address`, `birthday`, `educational_attainment`, `status`) VALUES
('2022-10001', 'Kaye', 'Ambagan', 'Urquiza', 'N/A', 'Female', 21, 'Single', 'Catholic', 'Filipino', 912345678, 'maurquiza@student.apc.edu.ph\n', '123456', 'Registrar Office', 'N/A', 'Record Specialized', 'Admin', 'Taguig City', '2000-12-05', 'Bachelor\'s', 'Regular'),
('2022-10002', 'Mary Jelean', 'Bautista', 'Ellema', 'N/A', 'Female', 20, 'Married', 'Catholic', 'Filipino', 912341546, 'mbellema@student.apc.edu.ph', '123456', 'School and Programs', 'SOCIT', 'Professor', 'User', 'Taguig City', '2001-08-10', 'Masteral\'s', 'Regular'),
('2022-10003', 'Louie', 'Romullo', 'Cortero', 'Jr.', 'Male', 21, 'Single', 'Christian', 'Filipino', 96548235, 'lrcortero@student.apc.edu.ph', '123456', 'Finance and Accounting Office', 'N/A', 'Internal Auditor', 'User', 'Pasay City', '2000-03-02', 'Bachelor\'s', 'Regular'),
('2022-10004', 'Joshua', 'Cruz', 'Magno', 'N/A', 'Male', 22, 'Married', 'Catholic', 'Filipino', 91234567, 'jbmagno@student.apc.edu.ph', '123456', 'Services', 'Academic Services', 'Guidance', 'User', 'Taguig City', '2000-02-10', 'Bachelor\'s', 'Leave'),
('2022-10005', 'Keith', 'Valdez', 'Topino', 'Jr.', 'Male', 22, 'Single', 'Catholic', 'Filipino', 917546325, 'ktopino@apc.edu.ph', '123456', 'Office of the President', 'Admission ', 'Director', 'User', 'Paranaque City', '2000-03-01', 'Masteral\'s', 'Irregular'),
('2022-10006', 'Timothy Ckhille', 'Guillermo', 'Velasco', '', 'Male', 23, 'Single', 'Catholic', 'Filipino', 915487628, 'tvelasco@apc.edu.ph', '123456', 'Office of the President', 'Human Resources', 'Director', 'Admin', 'Pasay City', '2000-07-13', 'Bachelor\'s', 'Regular'),
('2022-10007', 'Angela', 'Burnilla', 'Mallong', 'N/A', 'Female', 23, 'Single', 'Catholic', 'Filipino', 945128543, 'amallong@apc.edu.ph', '123456', 'School and Programs', 'SoMa', 'Program Director', 'User', 'Paranaque City', '1999-03-19', 'Masteral\'s', '');

-- --------------------------------------------------------

--
-- Table structure for table `employee_checklist`
--

CREATE TABLE `employee_checklist` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(100) NOT NULL,
  `document_name` varchar(99) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee_checklist`
--

INSERT INTO `employee_checklist` (`id`, `employee_id`, `document_name`, `created_at`, `updated_at`) VALUES
(10, '', '', '2022-03-11 16:20:54', '2022-03-11 16:20:54'),
(11, '', '', '2022-03-11 16:28:49', '2022-03-11 16:28:49'),
(12, '', 'Position Description Form', '2022-03-11 16:30:40', '2022-03-11 16:30:40'),
(13, '', 'Personal Data Sheets', '2022-03-11 16:32:38', '2022-03-11 16:32:38'),
(14, '2022-10001', 'Personal Data Sheets', '2022-03-11 16:36:15', '2022-03-11 16:36:15'),
(15, '2022-10005', 'SALN', '2022-03-11 16:36:30', '2022-03-11 16:36:30');

-- --------------------------------------------------------

--
-- Table structure for table `file_uploads`
--

CREATE TABLE `file_uploads` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(50) NOT NULL,
  `file_category` varchar(100) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_name` varchar(500) NOT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `file_uploads`
--

INSERT INTO `file_uploads` (`id`, `employee_id`, `file_category`, `file_path`, `file_name`, `description`, `status`, `created_at`) VALUES
(54, '2022-10003', 'Certificate', '../uploads/Louie Cortero/Certificate/Proofreading-Requisition-and-Certification-Form.pdf', 'Proofreading-Requisition-and-Certification-Form.pdf', 'Certificate from seminar', 'Approved', '2022-03-11 01:21:07'),
(55, '2022-10005', 'Certificate', '/../uploads/Keith Topino/Certificate/VELASCO_ACT2_ICTSRV1_BSIT-MI191.pdf', 'VELASCO_ACT2_ICTSRV1_BSIT-MI191.pdf', 'birth cert', 'Pending', '2022-03-12 14:30:44'),
(56, '2022-10005', 'Certificate', '/../uploads/Keith Topino/Certificate/Final Paper.pdf', 'Final Paper.pdf', 'cert test', 'Pending', '2022-03-12 14:31:54'),
(57, '2022-10005', 'Certificate', '/../uploads/Keith Topino/Certificate/Final Paper.pdf', 'Final Paper.pdf', 'certificate', 'Pending', '2022-03-14 00:02:07'),
(58, '2022-10005', 'Certificate', '../uploads/Keith Topino/Certificate/Exercise_04_-_Configuring_Initial_Switch_Settings_TOPINO_KEITH.pdf', 'Exercise_04_-_Configuring_Initial_Switch_Settings_TOPINO_KEITH.pdf', 'resume', 'Approved', '2022-03-14 00:02:54'),
(59, '2022-10005', 'Issurances', '/../uploads/Keith Topino/Issurances/Jell-q3-comvoip.pdf', 'Jell-q3-comvoip.pdf', 'INSURRANCE', 'Pending', '2022-03-14 00:03:58'),
(60, '2022-10005', 'Issurances', '/../uploads/Keith Topino/Issurances/COVIDDECLARATIONFORM_Fillable (1).pdf', 'COVIDDECLARATIONFORM_Fillable (1).pdf', 'resume', 'Pending', '2022-03-14 00:08:34');

-- --------------------------------------------------------

--
-- Table structure for table `profile_photos`
--

CREATE TABLE `profile_photos` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(100) NOT NULL,
  `file_name` varchar(100) NOT NULL,
  `path` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `profile_photos`
--

INSERT INTO `profile_photos` (`id`, `employee_id`, `file_name`, `path`, `created_at`, `updated_at`) VALUES
(10, '', '106235980_4061583597246329_6902681139174474628_n.jpg', '../profile_image/Keith Topino/avatar/106235980_4061583597246329_6902681139174474628_n.jpg', '2022-03-12 13:43:42', '2022-03-12 13:43:42'),
(11, '2022-10005', '106235980_4061583597246329_6902681139174474628_n.jpg', '../profile_image/Keith Topino/avatar/106235980_4061583597246329_6902681139174474628_n.jpg', '2022-03-12 13:45:58', '2022-03-12 13:45:58'),
(12, '2022-10006', 'IMG_0006.JPG', '../profile_image/Timothy Ckhille Velasco/avatar/IMG_0006.JPG', '2022-03-12 13:48:22', '2022-03-12 13:48:22'),
(13, '2022-10001', '178775877_1198139740626115_6798313654972596548_n.jpg', '../profile_image/Kaye Urquiza/avatar/178775877_1198139740626115_6798313654972596548_n.jpg', '2022-03-12 13:52:22', '2022-03-12 13:52:22'),
(14, '2022-10002', '271996669_4552072578236976_389983183930698281_n.jpg', '../profile_image/Mary Jelean Ellema/avatar/271996669_4552072578236976_389983183930698281_n.jpg', '2022-03-12 13:53:04', '2022-03-12 13:53:04'),
(15, '2022-10003', '69595044_486081515506680_5104490488661016576_n.jpg', '../profile_image/Louie Cortero/avatar/69595044_486081515506680_5104490488661016576_n.jpg', '2022-03-12 13:54:00', '2022-03-12 13:54:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`EmployeeID`);

--
-- Indexes for table `employee_checklist`
--
ALTER TABLE `employee_checklist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `file_uploads`
--
ALTER TABLE `file_uploads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile_photos`
--
ALTER TABLE `profile_photos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee_checklist`
--
ALTER TABLE `employee_checklist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `file_uploads`
--
ALTER TABLE `file_uploads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `profile_photos`
--
ALTER TABLE `profile_photos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
