<!DOCTYPE html>

<html lang="en">

<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link 
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Roboto:400,700"
    />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="../css/fontawesome.min.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/design_filter.css">
    <link rel="stylesheet" href="../css/templatemo-style-HR.css">
    <link rel="stylesheet" href="../css/reporttablestyle.css">
    <link rel="stylesheet" href="../css/style2.css">

  </head>

  <body id="reportsPage">
    <div class="" id="home">
    <nav class="navbar navbar-expand-xl">
            <div class="container h-100">
                <a class="navbar-brand" href="home.php">
                    <img class="two" src="../images/APC logo.png" width="50" height="50   ">
                </a>
                <button class="navbar-toggler ml-auto mr-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars tm-nav-icon"></i>
                </button>
            
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto h-100">
                        <li class="nav-item">
                            <a class="nav-link active" href="home.php">
                                <img class="two" src="../images/home.png" width="30" height="30">
                                <!-- Home -->
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <!-- Files -->  
                            <a class="nav-link" href="EmpEvalList.php"><img class="two" src="../images/blank-page.png" width="30" height="30"></a>
                        </li>
                        <!-- Upload -->
                        <li class="nav-item">
                            <div class="topnav-centered"></div>
                            <a href="upload.php" class="bn11"><img class="two" src="../images/upload.png" width="30" height="30"></a>
                            </a>
                        </li>
                        <!-- Register -->
                     
                        <!-- Report-->
                            <a class="nav-link" href="report.php"><img class="two" src="../images/export.png" width="30" height="30"></a>
                        </li>
</ul>
</div>
             
             <a class="bn11" href="profile.php"><img class="two" src="../images/user icon.png" width="30" height="30"></a>

</div>
           <a class="nav-item" href="logout.php">Log Out</a>
         </div>
       </div>
 </div>
</div>

</nav>
 
<div class="container">
      <div class="row col-md-6 col-md-offset-3">
        <div class="panel panel-primary">
          <div class="panel-heading text-center">
          </div>
          <div class="panel-body">
          <form action="dbRegister.php" method= "post">
              <div class="form-group">
                <label for="EmployeeID">Employee ID</label>
                <input
                  type="text"
                  class="form-control"
                  id="EmployeeID"
                  name="EmployeeID"
                />
              </div>
              <div class="form-group">
                <label for="firstName">First Name</label>
                <input
                  type="text"
                  class="form-control"
                  id="firstName"
                  name="firstName"
                />
              </div>
              <div class="form-group">
                <label for="lastName">Last Name</label>
                <input
                  type="text"
                  class="form-control"
                  id="lastName"
                  name="lastName"
                />
                </div>
              <div class="form-group">
                <label for="birthdate">birthdate</label>
                <input
                  type="date"
                  class="form-control"
                  id="birthdate"
                  name="birthdate"
                />
              </div>
              <div class="form-group">
                <label for="gender">Gender</label>
                <div>	
                  <label for="male" class="radio-inline"
                    ><input
                      type="radio"
                      name="gender"
                      value="Male"
                      id="male"
                    />Male</label
                  >
              
                  <label for="female" class="radio-inline"
                    ><input
                      type="radio"
                      name="gender"
                      value="Female"
                      id="female"
                    />Female</label
                  >
              <div class="form-group">
                <label for="email">Email</label>
                <input
                  type="text"
                  class="form-control"
                  id="email"
                  name="email"
                />
                <div class="form-group">
                <label for="address">Address</label>
                <input
                  type="text"
                  class="form-control"
                  id="address"
                  name="address"
                />
                <div class="form-group">
                <label for="contact">Contact Number</label>
                <input
                  type="text"
                  class="form-control"
                  id="contact"
                  name="contact"
                />
              </div>
              <div class="form-group">
                <label for="password">Password</label>
                <input
                  type="password"
                  class="form-control"
                  id="password"
                  name="password"
                />
                </div>   
                <div class="form-group">
                <label for="civil_status">Civil Status</label>
                <div>	
                  <label for="Single" class="radio-inline"
                    ><input
                      type="radio"
                      name="civil_status"
                      value="Single"
                      id="civil_Status"
                    />Single</label
                  >
                  <label for="Married" class="radio-inline"
                    ><input
                      type="radio"
                      name="civil_status"
                      value="Married"
                      id="civil_status"
                    />Married</label
                  >
                </div>
                
                
              <div class="form-group">
                <label for="user_type">User Type</label>
                <div>	
                  <label for="Admin" class="radio-inline"
                    ><input
                      type="radio"
                      name="user_type"
                      value="Admin"
                      id="Admin"
                    />Admin</label
                  >
                  <label for="user" class="radio-inline"
                    ><input
                      type="radio"
                      name="user_type"
                      value="User"
                      id="user"
                    />User</label
                  >
                </div>
              </div>              
              <div class="form-group">
                <label for="office">Department</label>
                <div>	
                  <label for="SOM" class="radio-inline"
                    ><input
                      type="radio"
                      name="office"
                      value="SOM"
                      id="SOM"
                    />School of Business Management</label
                  >
                  <label for="HRO" class="radio-inline"
                    ><input
                      type="radio"
                      name="office"
                      value="HRO"
                      id="HRO"
                    />Human Resource Office</label
                  >
                  <label for="ITRO" class="radio-inline"
                    ><input
                      type="radio"
                      name="office"
                      value="ITRO"
                      id="ITRO"
                    />ITRO</label
                  >

                  <label for="SOCIT" class="radio-inline"
                    ><input
                      type="radio"
                      name="office"
                      value="SOCIT"
                      id="SOCIT"
                    />School of Information Technology</label
                  >
                  <label for="SOMA" class="radio-inline"
                    ><input
                      type="radio"
                      name="office"
                      value="SOMA"
                      id="SOMA"
                    />School of Multimedia Arts</label
                  >
                </div>

              <input type="submit" class="btn btn-primary" />
            </form>
            <?php
              if (isset($_GET['registration'])) {
                if ($_GET['registration'] == 'success') {
                  echo '
                    <br>
                    <div class="alert alert-success" role="alert">
                      Registration successful.
                    </div>
                  ';
                } else if ($_GET['registration'] == 'failed') {
                  echo '
                  <br>
                    <div class="alert alert-danger" role="alert">
                      Registration failed. Please try again.
                    </div>
                  ';
                }
              }
            ?>
          </div>  
              </div>             
        </div>
      </div>
    </div>

<!-- partial -->
  <script src='https://use.fontawesome.com/4ecc3dbb0b.js'></script> 
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

</div>

<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/moment.min.js"></script>
<script src="js/Chart.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/tooplate-scripts.js"></script>
</body>

</html>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

</div>

<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/moment.min.js"></script>
<script src="js/Chart.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/tooplate-scripts.js"></script>
</body>

</html>