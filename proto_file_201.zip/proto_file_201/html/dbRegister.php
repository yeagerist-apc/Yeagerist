<?php
	require_once "dbConn.php";
	$EmployeeID = $_POST['EmployeeID'];
	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	$birthdate = $_POST['birthdate'];
	$gender = $_POST['gender'];
    $email = $_POST['email'];
	$address = $_POST['address'];
	$contact = $_POST['contact'];
	$password = $_POST['password'];
	$civil_status = $_POST['civil_status'];
	$office = $_POST['office'];
	$user_type = $_POST['user_type'];

	$sql = "
		INSERT INTO employees (
			EmployeeID,
			firstName, 
			lastName,
			birthdate, 
			gender,
			email,
			address,
			contact, 
			password,
			civil_status, 
			office,
			user_type
		) values(
			'${EmployeeID}', 
			'${firstName}', 
			'${lastName}',
			'${birthdate}', 
			'${gender}', 
			'${email}', 
			'${address}',
			'${contact}',
			'${password}',
			'${civil_status}', 
			'${office}',
			'${user_type}'
		)
	";

	if ($conn->query($sql)) {
		$conn->close();
		header("Location: register.php?registration=success");
	} else {
		$conn->close();
		header("Location: register.php?registration=failed");
	}
?>