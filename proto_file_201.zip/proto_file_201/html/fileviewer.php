<?php
if (isset($_POST['EmployeeSheet' ])) {
    header("content-type: application/pdf");
    readfile('file/Employee Information Form.pdf');
}
if (isset($_POST['NSO'])) {
    header("content-type: application/pdf");
    readfile('file/Certificate-of-Live-Birth.pdf');
}
if (isset($_POST['PHealth'])) {
    header("content-type: application/pdf");
    readfile('file/PhilHealth.pdf');
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Roboto:400,700"
    />
    <link rel="stylesheet" href="css/fontawesome.min.css" />
    <link rel="stylesheet" href="jquery-ui-datepicker/jquery-ui.min.css" type="text/css" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/templatemo-style-HR.css">
  </head>
  <body id="reportsPage">
    <div class="" id="home">
    <nav class="navbar navbar-expand-xl">
            <div class="container h-100">
                <a class="navbar-brand" href="home.php">
                    <img class="two" src="../images/APC logo.png" width="50" height="50   ">
                </a>
                <button class="navbar-toggler ml-auto mr-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars tm-nav-icon"></i>
                </button>
            
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto h-100">
                        <li class="nav-item">
                            <a class="nav-link active" href="home.php">
                                <img class="two" src="../images/home.png" width="30" height="30">
                                <!-- Home -->
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <!-- Files -->  
                            <a class="nav-link" href="EmpEvalList.php"><img class="two" src="../images/blank-page.png" width="30" height="30"></a>
                        </li>
                        <!-- Upload -->
                        <li class="nav-item">
                            <div class="topnav-centered"></div>
                            <a href="upload.php" class="bn11"><img class="two" src="../images/upload.png" width="30" height="30"></a>
                            </a>
                        </li>
                     
                        <!-- Re -->
                        <<li class="nav-item">
                            <a class="nav-link" href="report.php"><img class="two" src="../images/export.png" width="30" height="30"></a>
                        </li>

                        <div class="dropdown">
                        <button class="bn12" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="two" src="../images/user icon.png" width="40" height="40">
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                          <a class="dropdown-item" href="Profile.php">User</a> 
                          <a class="dropdown-item" href="logout.php">Log Out</a>
                        </div>
                      </div>
                </div>
</div>
 

        </nav>     
    <div class="container tm-mt-big tm-mb-big">
      <div class="row">
        <div class="col-xl-9 col-lg-10 col-md-12 col-sm-12 mx-auto">
          <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
            <div class="row">
              <div class="col-12">
                <h2 class="tm-block-title d-inline-block">File Viewer</h2>
                <div class="tm-notification-items">
                            <div class="media tm-notification-item">
                            <form action="FileViewer.php" method="post">
                                <div class="media-body">
                                    <p class="mb-2"><img src="folder.png" alt="Folder" style="width:70px;height:px;margin-right:15px;"><b><button class="bn14" name="EmployeeSheet">APC Employee Information Sheet</button></b>
                                    <span class="tm-small tm-text-color-secondary">6h ago.</span></p>   
                                </div>
                            </div>
                            <div class="media tm-notification-item">
                                <div class="media-body">
                                    <p class="mb-2"><img src="folder.png" alt="Folder" style="width:70px;height:px;margin-right:15px;"><b><button class="button" name="NSO">NSO Birth Certificate (photocopy)</button></b>
                                    <span class="tm-small tm-text-color-secondary">2h ago.</span></p>
                                </div>
                            </div>
                            <div class="media tm-notification-item">
                                <div class="media-body">
                                    <p class="mb-2"><img src="folder.png" alt="Folder" style="width:70px;height:px;margin-right:15px;"><b><button class="button" name="PHealth">PhilHealth ID/HD (photocopy)</button></b>
                                    <span class="tm-small tm-text-color-secondary">3h ago.</span></p>
                                </div>
                            </div>
                        </div>
                        </div>
                        </from>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<script src="js/jquery-3.3.1.min.js"></script>
<script src="jquery-ui-datepicker/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<footer class="tm-footer row tm-mt-small">
        <div class="col-12 font-weight-light">
        </div>
    </footer> 
</body>
</html>