<!DOCTYPE html>
<?php

session_start();


?>

<html lang="en">

<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link 
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Roboto:400,700"
    />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="../css/fontawesome.min.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/design_filter.css">
    <link rel="stylesheet" href="../css/templatemo-style-HR.css">
    <link rel="stylesheet" href="../css/reporttablestyle.css">
    <script type="text/javascript">
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
    $(function () {
        $("#category").change(function () {
            if ($(this).val() == 5) {
                $("#txtOther").removeAttr("disabled");
                $("#txtOther").focus();
            } else {
                $("#txtOther").attr("disabled", "disabled");
            }
        });
    });
</script>


  </head>

  <body id="reportsPage">
    <div class="" id="home">
    <nav class="navbar navbar-expand-xl">
            <div class="container h-100">
                <a class="navbar-brand" href="home.php">
                    <img class="two" src="../images/APC logo.png" width="50" height="50   ">
                </a>
                <button class="navbar-toggler ml-auto mr-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars tm-nav-icon"></i>
                </button>
            
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto h-100">
                        <li class="nav-item">
                            <a class="nav-link active" href="home.php">
                                <img class="two" src="../images/home.png" width="30" height="30">
                                <!-- Home -->
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <!-- Files -->  
                            <a class="nav-link" href="EmpEvalList.php"><img class="two" src="../images/blank-page.png" width="30" height="30"></a>
                        </li>
                        <!-- Upload -->
                        <li class="nav-item">
                            <div class="topnav-centered"></div>
                            <a href="upload.php" class="bn11"><img class="two" src="../images/upload.png" width="30" height="30"></a>
                            </a>
                        </li>
                        <!-- Register -->
                       
                        <!-- Report-->
                            <a class="nav-link" href="report.php"><img class="two" src="../images/export.png" width="30" height="30"></a>
                        </li>
</ul>
</div>
             
             <a class="bn11" href="profile.php"><img class="two" src="../images/user icon.png" width="30" height="30"></a>

</div>
           <a class="nav-item" href="logout.php">Log Out</a>
         </div>
       </div>
 </div>
</div>

</nav>
 
 <div class="container tm-mt-big tm-mb-big">
      <div class="row">
        <div class="col-xl-9 col-lg-10 col-md-12 col-sm-12 mx-auto">
          <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
            <div class="row">
              <div class="col-12">
                <h2 class="tm-block-title d-inline-block">Upload File</h2>
              </div>
            </div>
            <div class="row tm-edit-product-row">
              <div class="col-xl-6 col-lg-6 col-md-12">
                  <div class="form-group mb-3">
                  <form action="uploader.php" method= "post" enctype="multipart/form-data">
                    <label
                      >Name
                    </label>
                    <input
                      id="foldername"
                      name="foldername"
                      type="text"
                      class="form-control validate"
                      required
                    />
                  </div>
                  <div class="form-group mb-3">
                    <label
                      for="description"
                      >Description</label
                    >
                    <textarea
                      class="form-control validate"
                      rows="3"
                      name="description"
                      required
                    ></textarea>
                  </div>
                  <div class="form-group mb-3">
                    <label
                      for="category"
                      >Type of File</label
                    >
                    <select
                      class="custom-select tm-select-accounts"
                      id="category"
                      name="category" 
                    >
                      <option selected>Select Category</option>
                      <option value="Certificate">Certificate</option>
                      <option value="image">Image</option>
                      <option value="pdf">PDF</option>
                      <option value="link">LINK</option>
                      <option value="6">Others</option>


                    </select>
                    Other:
<input type="text" id="txtOther" disabled="disabled" />
                  </div>
              </div>
              <div class="col-xl-6 col-lg-6 col-md-12 mx-auto mb-4">
              <div class="files">
              <div id="text"></div>
              </div>
                <div class="custom-file mt-3 mb-3">
                  <input
                    type="button"
                    name="upload"
                    class="btn btn-primary btn-block mx-auto"
                    value="UPLOAD FILE"
                    onclick="document.getElementById('upload').click();"
                    id="file"
                  />
                </div>
                <input type="file" id="upload" name="upload" style="display:none" multiple> 
              </div>
              <div class="col-12">
                  <button type="submit" href="#demo-modal" class="btn btn-primary btn-block text-uppercase">Submit</button>
              </div>
              </div>
              </div>
              </div>
            </form>
            </div>
          </div>
        </div>
      </div>
    <footer class="tm-footer row tm-mt-small">
        <div class="col-12 font-weight-light">
        </div>
    </footer> 

    <div id="demo-modal" class="modal">
      <div class="modal__content">
         <center><h1>SUCCESS</h1></center> 
          <p>
              <h4>Your file is already submitted.</h4>
              you can now exit this message.
              <br>
              <br>
              <br><b>Thank You!</b>
          </p>         
         
          <a href="#" class="modal__close">&times;</a>
  </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="jquery-ui-datepicker/jquery-ui.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script type="text/javascript">
  $('#upload').bind('change', function() {
    var files = this.files;
    var i = 0;
    for(; i < files.length; i++) {
      var filename = files[i].name + "<br />";
      $("#text").append(filename);
    }
  });
</script>
  </body>
</html>