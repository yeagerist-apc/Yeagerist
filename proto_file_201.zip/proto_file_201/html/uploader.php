<?php
    require_once "dbConn.php";
    session_start();
    function get_size($size){
        $kb_size = $size / 1024;
        $format_size = number_format($kb_size, 2);
        return $format_size;
    }

    $size = get_size($_FILES['upload']['size']);


    $description = $_POST['description'];
    $category = $_POST['category'];
    $employee_id = $_SESSION['id'];

    $path = "../uploads/" . $_POST['foldername'] . "/" . $category;

    if($size < 5000){ 

        if(!file_exists($path)){

            mkdir($path, 0777, true); 
        }

        $temp_file=$_FILES['upload']['tmp_name'];

        if($temp_file!=""){

            $newfilepath = $path. "/".$_FILES['upload']['name'];

            if(move_uploaded_file($temp_file, $newfilepath)) {

                //save to db
                if (
                    $category == "Certificate"
                    //.. add here for other category
                ) {
                    $sql = "
                        INSERT INTO file_uploads (
                            employee_id, file_category, file_path, file_name, description, status
                        ) values(
                            '${employee_id}', 
                            '${category}', 
                            '${newfilepath}', 
                            '" . $_FILES['upload']['name'] . "', 
                            '${description}',
                            'Approved'
                        )
                    ";
                } else {
                    $sql = "
                        INSERT INTO file_uploads (
                            `employee_id`, `file_category`, `file_path`, `file_name`, `description`
                        ) values(
                            '${employee_id}', 
                            '${category}', 
                            '${homePath}/${newfilepath}', 
                            '" . $_FILES['upload']['name'] . "', 
                            '${description}'
                        )
                    ";
                }

                if ($conn->query($sql)) {
                    $conn->close();

                    // Send email
                    use PHPMailer\PHPMailer\PHPMailer;
                    use PHPMailer\PHPMailer\SMTP;
                    use PHPMailer\PHPMailer\Exception;
                
                    require '../PHPMailer/src/Exception.php';
                    require '../PHPMailer/src/PHPMailer.php';
                    require '../PHPMailer/src//SMTP.php';

                    $mail = new PHPMailer(true);

                    try {
                        //Server settings
                        // $mail->SMTPDebug = 1;
                        $mail->isSMTP();
                        $mail->Host = 'smtp.gmail.com';
                        $mail->SMTPAuth = true;
                        $mail->Username = 'yeagerist.apc@gmail.com';
                        $mail->Password = 'yeagerist2020';
                        $mail->SMTPSecure = 'tls';
                        $mail->Port = 587;

                        //Recipients
                        $mail->setFrom('yeagerist.apc@gmail.com', 'APC - Filescript');
                        $mail->addAddress('tgvelasco@student.apc.edu.ph'); // HR email

                        // Content
                        $mail->isHTML(true);
                        $mail->Subject = $_POST['foldername'] . " uploaded " . $category;
                        
                        $message = "
                            Hi HR,
                            <br><br>
                            " . $_POST['foldername'] . " uploaded " . $category . " successfully. Please see URL below:
                            <br>
                            <a href='http://localhost:8080/proto_file_201/" .  str_replace("..", "", $newfilepath) . "' target='_blank'>
                                http://localhost:8080/proto_file_201/" .  str_replace("..", "", $newfilepath) . "
                            </a>
                            
                            <br><br>
                            Cheers,
                            <br>
                            Yeagerist
                        ";

                        $mail->Body = $message;
                        $mail->send();
                        $mail->clearAddresses();
                        $mail->smtpClose();

                        header("Location: home.php?upload=success&email=sent");
                        exit;
                    } catch (Exception $e) {
                        header("Location: home.php?upload=success&email=failed");
                    }
                } else {
                    $conn->close();
                    header("Location: home.php?upload=failed");
                }
            }

    }else{
        echo "Error";

    }

}
?>