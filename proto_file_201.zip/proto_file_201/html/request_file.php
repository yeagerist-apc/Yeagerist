<?php
    require_once 'config.php';
    session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="../css/fontawesome.min.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/design_filter.css">
    <link rel="stylesheet" href="../css/templatemo-style-HR.css">
    <link rel="stylesheet" href="../css/reporttablestyle.css">
    <link rel="stylesheet" href="../css/stylenav.css">

    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
$("#Input").on("keyup", function() {
var value = $(this).val().toLowerCase();
$("#list tr").filter(function() {
$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
});
});
});
      </script>


    
</head>

<body>
<nav id="sidebar" style="position: fixed; min-height: auto !important; max-height: auto !important;">

<div class="img bg-wrap text-center py-4" style="background-image: url(images/bg_1.jpg);">
    <div class="user-logo">
    <?php
          require_once "dbConn.php";
          $sql = "SELECT * FROM profile_photos WHERE employee_id = '".$_SESSION['id'] ."'";
          $result = $conn->query($sql);
          $path = "";
          while($row = $result->fetch_assoc()) {
              $path = $row["path"];
          }
          if ($path) {
              echo '
                  <div style="width: 200px; height: 200px; overflow: hidden; margin: auto auto;" class="rounded-circle mt-5" >
                      <img id="" src="'. $path .'" style="width: 100%;">
                  </div>
              ';
          } else {
              echo '
                  <img class="two" src="../images/user icon.png" width="100" height="100">
              ';
          }
      ?>
    
    <br>
    <br>
        <h3>        <?php echo $_SESSION['firstName']; ?>
                    <?php echo $_SESSION['lastName']; ?>
      
      </p></h3>
        <h6>   <?php echo $_SESSION['id']; ?> </h6>
        <h6>   <?php echo $_SESSION['user_type']; ?> </h6>
    </div>
</div>
<ul class="list-unstyled components mb-5" style="margin-bottom: 0 !important;">
<li class="active">
<a href="home.php"><img class="two" src="../images/home.png" width="20" height="20">&nbsp&nbsp Home</a>
</li>
<li class="active">
<a href="request_file.php"><img class="two" src="../images/request_file.png" width="20" height="20">&nbsp&nbsp Request Files</a>
</li>
<li>
<a href="EmpEvalList.php"><img class="two" src="../images/blank-page.png" width="20" height="20"> &nbsp Employee List</a>
</li>
<li>
<a href="report.php"><img class="two" src="../images/export.png" width="20" height="20">&nbsp&nbsp Reports</a>
</li>
<li>
<a href="profile.php"><span class="fa fa-cog mr-3"></span> Profile</a>
</li>
<li>
<br>
<br>
<br>
<br>
<br>
<br>

<a href="logout.php" style="border-top-color: rgba(255, 255, 255, 0.05) !important; border-top: 9px solid;"><span class="fa fa-sign-out mr-3"></span> Sign Out</a>
</li>
</ul>

</nav>
        <div class="container">
            <div class="content-header">
            <div id="content" class="p-4 p-md-15 pt-15">              
                <div class="tm-bg-primary-dark tm-block tm-block-taller tm-block-scroll">
                <h2 class="tm-block-title">Request Files</h2>
                <input type="text" id="Input" placeholder="type to search">
                <table class="table" id="list">
                    <thead>
                        <tr>
                            <th scope="col">Employee ID</th>
                            <th scope="col">File Path</th>
                            <th scope="col">File category</th>
                            <th scope="col">File Name</th>
                            <th scope="col">status</th>
                            <th scope="col">        </th>
                            <th></th>
                        </tr>
                    </thead>
                    <?php
                $stmt = $db->prepare("select * from file_uploads");
                $stmt->execute();
                while($row = $stmt->fetch()){
                    ?>
                    <tr>
                    <td><?php echo $row['employee_id'] ?></td>
                    <td><?php echo $row['file_path']?></td>
                    <td><?php echo $row['file_category']?></td>
                    <td><?php echo $row['file_name']?></td>
                    <td colspan="<?php echo ($row['status'] != "Pending") ? 2 : 1; ?>" style="text-align: center;"><?php echo $row['status']?></td>
                    <?php 
                        if ($row['status'] == "Pending") {
                    ?>
                        <td style="width: 80px;">
                            <a href="Acceptfile.php?id=<?php echo $row['id']; ?>&employee_id=<?php echo $row['employee_id']; ?>&category=<?php echo $row['file_category']; ?>" class="bn3" style="background-color: green; padding: 5px;"><img class="two" src="../images/check.png" width="15" height="15"></a>
                            <a href="declinefile.php?id=<?php echo $row['id']; ?>&employee_id=<?php echo $row['employee_id']; ?>" class="bn3" style="background-color: red; padding: 5px;"><img class="two" src="../images/close.png" width="15" height="15"></a>
                        </td>
                    <?php
                        }
                    ?>
                    <td class="text=center">
                        <?php
                            if (
                                str_contains($row['file_name'], '.pdf') ||
                                str_contains($row['file_name'], '.png') ||
                                str_contains($row['file_name'], '.jpg') ||
                                str_contains($row['file_name'], '.jpeg') ||
                                str_contains($row['file_name'], '.bmp')
                            ) {
                                echo '<a href="' . $url . '/' . $row['file_path'] .'" class="bn12" target="_blank">View</a>';
                            } else {
                                echo '<a href="' . $url . '/' . $row['file_path'] .'" class="bn12" download>View</a>';
                            }
                        ?>
                        
                    </td>
                   

                </tr>
                <?php
                    }
                ?>

                </table>
            </div>
        </div>
    </div>
</div>
</div>
</div>


<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/moment.min.js"></script>
<script src="js/Chart.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/tooplate-scripts.js"></script>
</body>

</html>