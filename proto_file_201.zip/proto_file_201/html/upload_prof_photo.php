<?php

    require_once "dbConn.php";
    session_start();
    function get_size($size){
        $kb_size = $size / 1024;
        $format_size = number_format($kb_size, 2);
        return $format_size;
    }

    if (isset($_POST['submit'])) {

        $size = get_size($_FILES['avatar']['size']);
        $path = "../profile_image/" . $_POST['foldername'] . "/avatar";

        if($size < 5000){ 

            if(!file_exists($path)){
                mkdir($path, 0777, true); 
            }

            $temp_file=$_FILES['avatar']['tmp_name'];

            if($temp_file != ""){

                $newfilepath = $path. "/".$_FILES['avatar']['name'];

                if(move_uploaded_file($temp_file, $newfilepath)) {

                    $sql = "DELETE FROM profile_photos WHERE employee_id = '". $_POST['employee_id'] ."'";
                    $conn->query($sql);
                    
                    //save to db
                    $sql = "
                        INSERT INTO profile_photos (
                            `employee_id`, `file_name`, `path`
                        ) values(
                            '". $_POST['employee_id'] ."', 
                            '". $_FILES['avatar']['name'] ."', 
                            '${newfilepath}'
                        )
                    ";

                    $conn->query($sql);
                    $conn->close();
                    header("Location: ./EmpEvalList.php?upload=success");
                }
            } else {
                header("Location: ./EmpEvalList.php?upload=fail");
            }
        } else {
            header("Location: ./EmpEvalList.php?upload=fail");
        }
    }
    header("Location: ./EmpEvalList.php?upload=fail");
?>