<?php  
//export.php  

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

require '../vendor/autoload.php';

if(isset($_POST["export"])) {
    
    $conn = new mysqli('localhost', 'root', '', 'registrations');
    $sql = "SELECT * from employees";
    $result = $conn->query($sql);

    $spreadsheet = new Spreadsheet();
    $spreadsheet->getActiveSheet()->setAutoFilter('A1:R1');
    $sheet = $spreadsheet->getActiveSheet();

    $sheet->setCellValue('A1', 'Employee ID');
    $sheet->setCellValue('B1', 'First name');
    $sheet->setCellValue('C1', 'Last name');
    $sheet->setCellValue('D1', 'Suffix');
    $sheet->setCellValue('E1', 'Gender');
    $sheet->setCellValue('F1', 'Age');
    $sheet->setCellValue('G1', 'Civil Status');
    $sheet->setCellValue('H1', 'Religion');
    $sheet->setCellValue('I1', 'Citizenship');
    $sheet->setCellValue('J1', 'Contact');
    $sheet->setCellValue('K1', 'Email');
    $sheet->setCellValue('L1', 'Office');
    $sheet->setCellValue('M1', 'Department');
    $sheet->setCellValue('N1', 'Position');
    $sheet->setCellValue('O1', 'Address');
    $sheet->setCellValue('P1', 'Birthday');
    $sheet->setCellValue('Q1', 'Educational Attainment');
    $sheet->setCellValue('r1', 'status');
    
    $ctr = 2;
    if ($result-> num_rows > 0 ) {
        while ($row = $result-> fetch_assoc()){
            $sheet->setCellValue('A' . $ctr, $row["EmployeeID"]);
            $sheet->setCellValue('B' . $ctr, $row["firstName"]);
            $sheet->setCellValue('C' . $ctr, $row["lastName"]);
            $sheet->setCellValue('D' . $ctr, $row["suffixName"]);
            $sheet->setCellValue('E' . $ctr, $row["gender"]);
            $sheet->setCellValue('F' . $ctr, $row["age"]);
            $sheet->setCellValue('G' . $ctr, $row["civil_status"]);
            $sheet->setCellValue('H' . $ctr, $row["religion"]);
            $sheet->setCellValue('I' . $ctr, $row["citizenship"]);
            $sheet->setCellValue('J' . $ctr, $row["contact"]);
            $sheet->setCellValue('K' . $ctr, $row["email"]);
            $sheet->setCellValue('L' . $ctr, $row["office"]);
            $sheet->setCellValue('M' . $ctr, $row["department"]);
            $sheet->setCellValue('N' . $ctr, $row["position"]);
            $sheet->setCellValue('O' . $ctr, $row["address"]);
            $sheet->setCellValue('P' . $ctr, $row["birthday"]);
            $sheet->setCellValue('Q' . $ctr, $row["educational_attainment"]);
            $sheet->setCellValue('r' . $ctr, $row["status"]);
            $ctr++;
        }
    }

    $writer = new Xlsx($spreadsheet);
    $writer->save('employee_report.xlsx');

    header("Location: ./employee_report.xlsx");
}
?>

