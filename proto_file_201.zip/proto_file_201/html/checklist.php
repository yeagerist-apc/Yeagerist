<!DOCTYPE html>
<?php

session_start();


?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="../css/fontawesome.min.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/design_filter.css">
    <link rel="stylesheet" href="../css/templatemo-style.css">
    <link rel="stylesheet" href="../css/reporttablestyle.css">
    <link rel="stylesheet" href="../css/checklist1.css">
    <link rel="stylesheet" href="../css/stylenav.css">

    
</head>

<body id="reportsPage">
<div class="wrapper d-flex align-items-stretch">
    <nav id="sidebar" style="position: fixed; min-height: auto !important; max-height: auto !important;">

              <div class="img bg-wrap text-center py-4" style="background-image: url(images/bg_1.jpg);">
                  <div class="user-logo">
                  <?php
                        require_once "dbConn.php";
                        $sql = "SELECT * FROM profile_photos WHERE employee_id = '".$_SESSION['id'] ."'";
                        $result = $conn->query($sql);
                        $path = "";
                        while($row = $result->fetch_assoc()) {
                            $path = $row["path"];
                        }
                        if ($path) {
                            echo '
                                <div style="width: 200px; height: 200px; overflow: hidden; margin: auto auto;" class="rounded-circle mt-5" >
                                    <img id="" src="'. $path .'" style="width: 100%;">
                                </div>
                            ';
                        } else {
                            echo '
                                <img class="two" src="../images/user icon.png" width="100" height="100">
                            ';
                        }
                    ?>
                  
                  <br>
                  <br>
                      <h3>        <?php echo $_SESSION['firstName']; ?>
                                  <?php echo $_SESSION['lastName']; ?>
                    
                    </p></h3>
                      <h6>   <?php echo $_SESSION['id']; ?> </h6>
                      <h6>   <?php echo $_SESSION['user_type']; ?> </h6>
                  </div>
              </div>
        <ul class="list-unstyled components mb-5" style="margin-bottom: 0 !important;">
        <li class="active">
            <a href="home.php"><img class="two" src="../images/home.png" width="20" height="20">&nbsp&nbsp Home</a>
          </li>
          <li class="active">
            <a href="request_file.php"><img class="two" src="../images/request_file.png" width="20" height="20">&nbsp&nbsp Request Files</a>
          </li>
          <li>
              <a href="EmpEvalList.php"><img class="two" src="../images/blank-page.png" width="20" height="20"> &nbsp Employee List</a>
          </li>
          <li>
            <a href="report.php"><img class="two" src="../images/export.png" width="20" height="20">&nbsp&nbsp Reports</a>
          </li>
          <li>
            <a href="profile.php"><span class="fa fa-cog mr-3"></span> Profile</a>
          </li>
          <li>
              <br>
              <br>
              <br>
              <br>
              <br>
              <br>
              
            <a href="logout.php" style="border-top-color: rgba(255, 255, 255, 0.05) !important; border-top: 9px solid;"><span class="fa fa-sign-out mr-3"></span> Sign Out</a>
          </li>
        </ul>

        </nav>

</section>


<div class="container tm-mt-big tm-mb-big">
      <div class="row">
        <div class="col-xl-15 col-lg-20 col-md-12 col-sm-12 mx-auto">
            <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
                <div class="row"><a href="EmpEvalList.php" class="bn11"><img class="two" src="../images/back.png" width="30" height="30"></a>
                    <div class="col-12">
                        <h2 class="tm-block-title d-inline-block">Profile</h2>

                        <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                            <div style="width: 200px; height: 200px; overflow: hidden;" class="rounded-circle mt-5" >
                                <?php
                                    require_once "dbConn.php";
                                    $sql = "SELECT * FROM profile_photos WHERE employee_id = '". $_GET['employee_id'] ."'";
                                    $result = $conn->query($sql);
                                    $path = "";
                                    while($row = $result->fetch_assoc()) {
                                        $path = $row["path"];
                                    }
                                    if ($path) {
                                        echo '
                                            <img id="avatar-img" src="'. $path .'" style="width: 100%;">
                                        ';
                                    } else {
                                        echo '
                                            <img id="avatar-img" src="../images/user icon.png" style="width: 100%;">
                                        ';
                                    }
                                ?>


                                
                            </div>
                            <br>
                            <form action="upload_prof_photo.php" method="post" enctype="multipart/form-data">
                                <label for="avatar">Choose a profile picture:</label>
                                <br>
                                <input type="hidden" name="employee_id" value="<?php echo $_GET['employee_id']; ?>" />
                                <input type="hidden" name="foldername" value="<?php echo $_GET['fname'] . " " . $_GET['lname']; ?>" />
                                <input type="file"
                                    id="avatar" 
                                    name="avatar"
                                    accept="image/png, image/jpeg"
                                    style="
                                        position: relative;
                                        right: 0;
                                        visibility: visible;
                                        opacity: 1;
                                    "
                                >
                                <br>
                                <input 
                                    type="submit" 
                                    name="submit" 
                                    value="Upload" 
                                    style="
                                        margin: auto auto;
                                        display: block;
                                        float: none;
                                        margin-top: 20px;
                                        padding: 5px
                                    "
                                />
                            </form>
                            <br>
                            <span class="font-weight-bold">
                                <p class="employee"><?php echo $_GET['fname'] . " " . $_GET['lname'];  ?></p>
                            </span>
                            
                            <span class="text-black-50">
                                <?php echo $_GET['email']; ?></p>
                            </span>
                        </div>
                    </div>
                    <label></label>
            

                </div>
            <div class="container rounded bg-white mt-5 mb-5">
              <div class="row">
                <div class="col-md-2 border-right"></div>
                  <div class="col-md-5 border-right">
                      <div class="p-3 py-5">

   


                          <div class="row mt-3">

                          <div class="col-md-12"><label class="labels">Gender</label><p>
                              <?php echo $_GET['gender']; ?>
                                </p> </div>

                              <div class="col-md-12"><label class="labels">Mobile Number</label><p>
                              <?php echo $_GET['contact']; ?>
                              </p></div>

                              <div class="col-md-12"><label class="labels">Address Line</label><p> 
                              <?php echo $_GET['address']; ?>
                                </p> </div>


                            <div class="col-md-12"><label class="labels">Educational Attainment</label> 
                            <p>
                            <?php echo $_GET['educational_attainment']; ?>
                                </p> </div>
                                <div class="col-md-12"><label class="labels">Status</label> 
                           <p>
                           <?php echo $_GET['status']; ?>
                                </p> </div>

                    
                          
                          
                          
                            </div>
                      </div>
                  </div>
                  
        
                  <div class="col-md-4"> 
    
                      <div class="p-3 py-5">
                           <div class="col-md-12"><label class="labels">Civil Statust</label> 
                            <p>
                            <?php echo $_GET['civil_status']; ?>
                                </p> </div>

                          <div class="col-md-12"><label class="labels">Birthdate</label> 
                           <p>
                           <?php echo $_GET['birthday']; ?>
                                </p> </div>
                                
                          <div class="col-md-12"><label class="labels">Office</label> 
                           <p>
                           <?php echo $_GET['office']; ?>
                                </p> </div>
                                <div class="col-md-12"><label class="labels">Position</label> 
                           <p>
                           <?php echo $_GET['position']; ?>
                                </p> </div>
                 
                  </div>
              </div>
                </div>
                </div>

            <hr>

            <h2 class="tm-block-title d-inline-block">Checklist</h2>
 


                 
            <table class="table">
                <thead>
                    <tr>

                        <th scope="col">File name</th>
                        <th scope="col">File Type</th>
                        <th scope="col">Submitted at</th>

                    </tr>
                </thead>
                <tbody>
                    <?php

                        $sql = "SELECT * from employee_checklist WHERE employee_id ='". $_GET['employee_id'] ."'";
                        $result = $conn-> query($sql);

                        if ($result-> num_rows > 0 ) {

                            while ($row = $result-> fetch_assoc()){
                                echo "
                                <tr>
                                    <td>". $row["employee_id"] . "</td>
                                    <td>". $row["document_name"] . "</td>
                                    <td>". $row["created_at"] . "</td>
                                <tr>
                                ";
                            }
                        }

                    ?>
                </tbody>
            </table>

            <hr>

            <form action ="checklistDB.php" method ="POST">
                <div class="ratingscale">
                    <input type="hidden" name="employee_id" value="<?php echo $_GET['employee_id']; ?>" />
                    <b><p class="ratingscales">CHECKLIST:</p></b>
                </div>
                <table style="width: 100%;">
                    <tr class="question1">
                        <td class="qbg">
                            <p>&emsp;&emsp;</p>
                        </td>
                        <td class="qbg">
                            <p class="numbers"></p>
                        </td>
                    </tr>
                    <tr class="questions">
                        <th>
                            <p>Personal Data Sheet</p>
                        </th>
                        <th style="text-align: right;">
                            <p>&ensp;
            
                                &emsp;<input type="checkbox" name ="documents[]" value= "Personal Data Sheets">&emsp;&emsp;

                        </th>
                    </tr>

                    <tr class="question1">
                        <td class="qbg">
                            <p>&emsp;&emsp;</p>
                        </td>
                        <td class="qbg">
                            <p class="numbers"></p>
                        </td>
                    </tr>
                    <tr class="questions">
                        <th>
                            <p>Position Description Form</p>
                        </th>
                        <th style="text-align: right;">
                            <p>&ensp;
                            
                                &emsp;<input type="checkbox" name ="documents[]" value= "Position Description Form">&emsp;&emsp;

                        </th>
                    </tr>

                    <tr class="question1">
                        <td class="qbg">
                            <p>&emsp;&emsp;</p>
                        </td>
                        <td class="qbg">
                            <p class="numbers"></p>
                        </td>
                    </tr>
                    <tr class="questions">
                        <th>
                            <p>Professional Teachers Licenses</p>
                        </th>
                        <th style="text-align: right;">
                            <p>&ensp;
                            
                                &emsp;<input type="checkbox" name ="documents[]" value= "Professional Teachers Licenses">&emsp;&emsp;

                        </th>
                    </tr>

                    <tr class="question1">
                        <td class="qbg">
                            <p>&emsp;&emsp;</p>
                        </td>
                        <td class="qbg">
                            <p class="numbers"></p>
                        </td>
                    </tr>
                    <tr class="questions">
                        <th>
                            <p>Statement of Assets, Liabilities and Networth</p>
                        </th>
                        <th style="text-align: right;">
                            <p>&ensp;
                            
                                &emsp;<input type="checkbox" name ="documents[]" value= "SALN">&emsp;&emsp;

                        </th>
                    </tr>

                    <tr class="question1">
                        <td class="qbg">
                            <p>&emsp;&emsp;</p>
                        </td>
                        <td class="qbg">
                            <p class="numbers"></p>
                        </td>
                    </tr>
                    <tr class="questions">
                        <th>
                            <p>Notices of Salary Adjustments/Step Increments</p>
                        </th>
                        <th style="text-align: right;">
                            <p>&ensp;
                            
                                &emsp;<input type="checkbox" name ="documents[]" value= "Notices of Salary Adjustments/Step Increments">&emsp;&emsp;

                        </th>
                    </tr>

                    <tr class="question1">
                        <td class="qbg">
                            <p>&emsp;&emsp;</p>
                        </td>
                        <td class="qbg">
                            <p class="numbers"></p>
                        </td>
                    </tr>
                    <tr class="questions">
                        <th>
                            <p>Medical Certificate </p>
                        </th>
                        <th style="text-align: right;">
                            <p>&ensp;
                            
                                &emsp;<input type="checkbox" name ="documents[]" value= "Medical Certificate">&emsp;&emsp;

                        </th>
                    </tr>

                    <tr class="question1">
                        <td class="qbg">
                            <p>&emsp;&emsp;</p>
                        </td>
                        <td class="qbg">
                            <p class="numbers"></p>
                        </td>
                    </tr>
                    <tr class="questions">
                        <th>
                            <p>NBI Clearance</p>
                        </th>
                        <th style="text-align: right;">
                            <p>&ensp;
                            
                                &emsp;<input type="checkbox" name ="documents[]" value= "NBI Clearance">&emsp;&emsp;

                        </th>
                    </tr>

                    <tr class="question1">
                        <td class="qbg">
                            <p>&emsp;&emsp;</p>
                        </td>
                        <td class="qbg">
                            <p class="numbers"></p>
                        </td>
                    </tr>
                    <tr class="questions">
                        <th>
                            <p>SSS ID/Number</p>
                        </th>
                        <th style="text-align: right;">
                            <p>&ensp;
                            
                                &emsp;<input type="checkbox" name ="documents[]" value= "SSS ID/Number">&emsp;&emsp;

                        </th>
                    </tr>

                    <tr class="question1">
                        <td class="qbg">
                            <p>&emsp;&emsp;</p>
                        </td>
                        <td class="qbg">
                            <p class="numbers"></p>
                        </td>
                    </tr>
                    <tr class="questions">
                        <th>
                            <p>PhilHealth ID/Number</p>
                        </th>
                        <th style="text-align: right;">
                            <p>&ensp;
                            
                                &emsp;<input type="checkbox" name ="documents[]" value= "PhilHealth ID/Number">&emsp;&emsp;

                        </th>
                    </tr>
                    <tr class="question1">
                        <td class="qbg">
                            <p>&emsp;&emsp;</p>
                        </td>
                        <td class="qbg">
                            <p class="numbers"></p>
                        </td>
                    </tr>
                    <tr class="questions">
                        <th>
                            <p>Birth certificate</p>
                        </th>
                        <th style="text-align: right;">
                            <p>&ensp;
                            
                                &emsp;<input type="checkbox" name ="documents[]" value= "Birth Certificate">&emsp;&emsp;

                        </th>
                    </tr>

                    <tr class="question1">
                        <td class="qbg">
                            <p>&emsp;&emsp;</p>
                        </td>
                        <td class="qbg">
                            <p class="numbers"></p>
                        </td>
                    </tr>
                    <tr class="questions">
                        <th>
                            <p>School Diplomas and Transcript of Records</p>
                        </th>
                        <th style="text-align: right;">
                            <p>&ensp;
                            
                                &emsp;<input type="checkbox" name ="documents[]" value= "School Diplomas and Transcript of Records">&emsp;&emsp;

                        </th>
                    </tr>

                    <tr class="question1">
                        <td class="qbg">
                            <p>&emsp;&emsp;</p>
                        </td>
                        <td class="qbg">
                            <p class="numbers"></p>
                        </td>
                    </tr>
                    <tr class="questions">
                        <th>
                            <p>Marriage Contract</p>
                        </th>
                        <th style="text-align: right;">
                            <p>&ensp;
                            
                            &emsp;<input type="checkbox" name ="documents[]" value= "Marriage Contract">&emsp;&emsp;

                        </th>
                    </tr>
                    <tr class="questions">
                        <td colspan="2">
                            <input type="submit" class="submitbutton" name="submit" value="Submit"  style="margin: auto auto; display: block;float: none;"/>
                        </td>
                    </tr>
                </table>
            </form>
        </div>


   

    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../js/jquery-ui-datepicker/jquery-ui.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#avatar").change(function () {
                var file = $("#avatar").get(0).files[0];
                if (file){
                    var reader = new FileReader();

                    reader.onload = function(){
                        $("#avatar-img").attr("src", reader.result);
                    }

                    reader.readAsDataURL(file);
                }
            })
        });
    </script>
  </body>
</html>
