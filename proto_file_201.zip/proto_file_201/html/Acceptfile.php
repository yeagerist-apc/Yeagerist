<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require '../PHPMailer/src/Exception.php';
    require '../PHPMailer/src/PHPMailer.php';
    require '../PHPMailer/src//SMTP.php';

    require_once "dbConn.php";
    session_start();

    $id = $_GET['id'];
    $employee_id = $_GET['employee_id'];
    $category = $_GET['category'];

    $sql="
        UPDATE file_uploads set status = 'Approved' WHERE id = $id
    ";

    if ($conn->query($sql)) {
        $sql = "SELECT * FROM employees WHERE EmployeeID = '$employee_id'";
        $result = $conn->query($sql);
        $employee_name = "";
        $employee_email = "";
        while($row = $result->fetch_assoc()) {
            $employee_name = $row["firstName"] . " " . $row["lastName"];
            $employee_email = $row["email"];
        }

        // Send email
        $mail = new PHPMailer(true);

        try {
            //Server settings
            // $mail->SMTPDebug = 1;
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'yeagerist.apc@gmail.com';
            $mail->Password = 'yeagerist2020';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            //Recipients
            $mail->setFrom('yeagerist.apc@gmail.com', 'APC - Filescript');
            $mail->addAddress($employee_email);

            // Content
            $mail->isHTML(true);
            $mail->Subject = $_POST['foldername'] . " uploaded " . $category;
            
            $message = "
                Hi " . $employee_name  . ",
                <br><br>
                Your uploaded " . $category . " has been <span style='color: green;'><b>approved</b></span>..
                
                <br><br>
                Cheers,
                <br>
                HR
            ";

            $mail->Body = $message;
            $mail->send();
            $mail->clearAddresses();
            $mail->smtpClose();

            $conn->close();
            header("Location: request_file.php?upload=success&email=sent");
        } catch (Exception $e) {
            header("Location: request_file.php?upload=success&email=failed");
        }
    } else {
        $conn->close();
        header("Location: request_file.php?upload=failed");
    }
?>


