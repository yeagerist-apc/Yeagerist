<?php

$conn = new mysqli('localhost', 'root', '', 'registrations');




if($conn->connect_errno){
    die("Connection Failed : ". $conn->connect_error);
}