<!DOCTYPE html>
<?php

session_start();


?>


<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="../css/fontawesome.min.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/design_filter.css">
    <link rel="stylesheet" href="../css/templatemo-style-HR.css">
    <link rel="stylesheet" href="../css/reporttablestyle.css">
    <link rel="stylesheet" href="../css/stylenav.css">


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
$("#Input").on("keyup", function() {
var value = $(this).val().toLowerCase();
$("#list tr").filter(function() {
$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
});
});
});
      </script>
    
</head>

<body id="reportsPage">
<div class="wrapper d-flex align-items-stretch">
<nav id="sidebar" style="position: fixed; min-height: auto !important; max-height: auto !important;">

<div class="img bg-wrap text-center py-4" style="background-image: url(images/bg_1.jpg);">
    <div class="user-logo">
    <?php
          require_once "dbConn.php";
          $sql = "SELECT * FROM profile_photos WHERE employee_id = '".$_SESSION['id'] ."'";
          $result = $conn->query($sql);
          $path = "";
          while($row = $result->fetch_assoc()) {
              $path = $row["path"];
          }
          if ($path) {
              echo '
                  <div style="width: 200px; height: 200px; overflow: hidden; margin: auto auto;" class="rounded-circle mt-5" >
                      <img id="" src="'. $path .'" style="width: 100%;">
                  </div>
              ';
          } else {
              echo '
                  <img class="two" src="../images/user icon.png" width="100" height="100">
              ';
          }
      ?>
    
    <br>
    <br>
        <h3>        <?php echo $_SESSION['firstName']; ?>
                    <?php echo $_SESSION['lastName']; ?>
      
      </p></h3>
        <h6>   <?php echo $_SESSION['id']; ?> </h6>
        <h6>   <?php echo $_SESSION['user_type']; ?> </h6>
    </div>
</div>
<ul class="list-unstyled components mb-5" style="margin-bottom: 0 !important;">
<li class="active">
<a href="home.php"><img class="two" src="../images/home.png" width="20" height="20">&nbsp&nbsp Home</a>
</li>
<li class="active">
<a href="request_file.php"><img class="two" src="../images/request_file.png" width="20" height="20">&nbsp&nbsp Request Files</a>
</li>
<li>
<a href="EmpEvalList.php"><img class="two" src="../images/blank-page.png" width="20" height="20"> &nbsp Employee List</a>
</li>
<li>
<a href="report.php"><img class="two" src="../images/export.png" width="20" height="20">&nbsp&nbsp Reports</a>
</li>
<li>
<a href="profile.php"><span class="fa fa-cog mr-3"></span> Profile</a>
</li>
<li>
<br>
<br>
<br>
<br>
<br>
<br>

<a href="logout.php" style="border-top-color: rgba(255, 255, 255, 0.05) !important; border-top: 9px solid;"><span class="fa fa-sign-out mr-3"></span> Sign Out</a>
</li>
</ul>

</nav>
        <div class="container">
        <div id="content" class="p-4 p-md-15 pt-15">               
                        <div class="col-12 tm-block-col">
                    <div class="tm-bg-primary-dark tm-block tm-block-taller tm-block-scroll">
                        <h2 class="tm-block-title">Employee List</h2>

                        <input type="text" id="Input" placeholder="type to search">


                        <table id="list">
 
                        

                            <tr>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Gender</th>
                                <th>Email</th>
                                <th>Office</th>
                                <th>Status</th>

                            </tr>
                            

                        <?php
                         

                        $conn = new mysqli('localhost', 'root', '', 'registrations');
                    
                        
                        if($conn->connect_errno){
                            die("Connection Failed : ". $conn->connect_error);
                        }
                        $sql = "SELECT * from employees";
                        $result = $conn-> query($sql);
                        
                        if ($result-> num_rows > 0 ) {
                        
                            while ($row = $result-> fetch_assoc()){
                                echo "
                                    <tr>
                                        <td>". $row["firstName"] . "</td>
                                        <td>". $row["lastName"] . "</td>
                                        <td>". $row["gender"] . "</td>
                                        <td>". $row["email"] . "</td>
                                        <td>". $row["office"] . "</td>
                                        <td>". $row["status"] . "</td>
                                      
                                    <tr>
                                ";

                            }
                            echo "</table>";
                        }
                        else {
                            echo "0 result";
                        }
                        $conn-> close();
                        
                        ?>
                        <br>
                        <br>
                        
                                       <!-- export -->
                        <form method="post" action="export.php">
                            <input type="submit" name="export" class="btn btn-success" value="Export to Excel" />
     
                        </form>
                        </table>
        </div>
      
    </div>
                    </div>
                    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/moment.min.js"></script>
    <script src="js/Chart.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/tooplate-scripts.js"></script>
    <script>
        Chart.defaults.global.defaultFontColor = 'white';
        let ctxLine,
            ctxBar,
            ctxPie,
            optionsLine,
            optionsBar,
            optionsPie,
            configLine,
            configBar,
            configPie,
            lineChart;
        barChart, pieChart;
        // DOM is ready
        $(function () {
            drawLineChart(); // Line Chart
            drawBarChart(); // Bar Chart
            drawPieChart(); // Pie Chart

            $(window).resize(function () {
                updateLineChart();
                updateBarChart();                
            });
        })
    </script>
</body>

</html>