<?php
    require_once "dbConn.php";
    session_start();

    $employee_id = $_POST['employee_id'];
    $documents = $_POST['documents'];

    $isSaveAll = false;
    foreach ($documents as $document) {
        //save to db


        $sql = "
            INSERT INTO employee_checklist (
                `employee_id`, `document_name`
            ) values(
                '${employee_id}', 
                '${document}'
                
            )
        ";
        if(!$conn->query($sql)) {
            $isSaveAll = false;
            break;
        }
        $isSaveAll = true;
    }
    $conn->close();
    if ($isSaveAll) {
        header("Location: EmpEvalList.php?upload=success");
    } else {
        header("Location: EmpEvalLIST.php?upload=failed");
    }

?>