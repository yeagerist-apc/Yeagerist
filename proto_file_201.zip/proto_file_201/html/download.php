<?php
include "config.php";
if(isset($GET['id'])){

$id = $_GET['id'];
$stat = $db->prepare("select * from file_uploads where id?=");
$stat ->bindParam(1, $id);
$stat ->execute();
$data = $stat->fetch();

$file = 'media/' .$data['file_path'];

    if(file_exist($file)){

header('file-ID: ' . $data['id']);
header('Employee:  ' . $data['employee_id']);
header('Type' . $data['file_type']);
header('file-Path ' . $data['file_path']);
header('Content-description: ' . $data['description']);
header('Status ' . $data['status']);
header('Content-Lenght  ' . filesize($file));
readfile($file);
exit;
  

}
}